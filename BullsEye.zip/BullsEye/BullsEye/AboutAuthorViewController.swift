//
//  AboutAuthorViewController.swift
//  BullsEye
//
//  Created by islab on 2019/4/13.
//  Copyright © 2019 islab. All rights reserved.
//

import UIKit
import WebKit

class AboutAuthorViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func close(){
        dismiss(animated: true, completion: nil)
    }
    
}
